// src/pages/Cakes.js
import React from 'react';
import CakeCard from '../components/CakeCard';

const cakesData = [
    { id: 1, name: 'Chocolate Cake', price: 'rupees 220', image: 'https://tse4.mm.bing.net/th?id=OIP.zJ4OwfLZrL9qABqx-HSYWwHaHa&pid=Api&P=0&h=180' },
    { id: 2, name: 'Vanilla Cake', price: 'rupees 115', image: 'https://tse3.mm.bing.net/th?id=OIP.ZIQ1S_VWCELnbWiGuuPZpgHaKX&pid=Api&P=0&h=180' },
    { id: 3, name: 'Fruit cake', price: 'rupees 200', image: 'https://drivemehungry.com/wp-content/uploads/2022/09/fresh-fruit-cake-5.jpg' },
    { id: 4, name: 'Red velvet', price: 'rupees 310', image: 'https://th.bing.com/th/id/OIP.uNQZfoh-kjfvsQ_Pn7Ba2QHaJQ?w=169&h=212&c=7&r=0&o=5&dpr=1.3&pid=1.7' },
    
];

function Cakes() {
    return (
        <div className="cakes">
            <h2>Our Cakes</h2>
            <div className="cakes-grid">
                {cakesData.map((cake) => (
                    <CakeCard key={cake.id} cake={cake} />
                ))}
            </div>
        </div>
    );
}

export default Cakes;
